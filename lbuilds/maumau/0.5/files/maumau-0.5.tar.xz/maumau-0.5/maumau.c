/***************************************************************************
 *   Copyright (C) 2009 by Max Reitz                                       *
 *   xanclic@googlemail.com                                                *
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 *   This program is distributed in the hope that it will be useful,       *
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of        *
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *
 *   GNU General Public License for more details.                          *
 *                                                                         *
 *   You should have received a copy of the GNU General Public License     *
 *   along with this program; if not, write to the                         *
 *   Free Software Foundation, Inc.,                                       *
 *   59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.             *
 ***************************************************************************/

//define this if you are using Linux, Paloxena or another OS with full Unicode support
#define FULL_UNICODE

#include "libmaumau.h"
#include <ctype.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <readline/readline.h>
#include <readline/history.h>

#define SYMBOL_HEARTS   3
#define SYMBOL_DIAMONDS 4
#define SYMBOL_CLUBS    5
#define SYMBOL_SPADES   6

#define MUST_NOTHING 0x00
#define MUST_TAKE    0x01
#define MUST_WAIT    0x02

const char *english[22] =
{
    "Unknown parameters.",
    "Unknown parameter.",
    "A simple text-based Mau-Mau.\n"
            "RULES:\n"
            "  First of all, the standard rules rule. Pay attention: Who wants to draw a\n"
            "  card, because he cannot or does not want to put one, has to pause for a\n"
            "  round.\n"
            "SPECIAL RULES:\n"
            "  A jack may be put on every card (also on other jacks). The player who put it\n"
            "  may choose the colour of the next card afterwards.\n"
            "  If a 7 is being put, the other player has to draw two cards before his turn,\n"
            "  unless he is able to answer with a 7 or 10. If a 10 is being put, the other\n"
            "  player has to draw one card before his turn, unless he is able to answer with\n"
            "  a 7 or 10. \"To answer\" means to put a \"draw-card\" (7 or 10) immediately on\n"
            "  another draw-card and hence increasing the number of cards to draw plus\n"
            "  giving the burden of drawing back to the first player.\n"
            "  An ace lets the other player pause for a round.\n",
            "You",
            "Your opponent",
            "You and your opponent",
            "Current colour",
            "You have to draw %i %s, but you are able to parry that.",
            "Do you want to put a 7 or 10?",
            "card",
            "cards",
            "Which card do you want to put? (\"none\" for none)",
            "none",
            "Unfortunately you do not have this card.",
            "(just 7 or 10).",
            "Congratulations! You have won the game!",
            "You have to draw %i %s.",
            "You have to pause. Press enter.",
            "Unfortunately you cannot put that card",
            "Because you have put a jack, you may now choose a color.",
            "Dou you want clubs (K), spade (P), hearts (H) oder diamonds (C)?",
            "Unfortunately you have lost!"
};
const char *german[22] =
{
    "Unbekannte Parameter.",
    "Unbekannter Parameter.",
    "Ein einfaches Textbasiertes Mau-Mau.\n"
            "REGELN:\n"
            "  Zunächst gelten die Standardregeln von Mau-Mau. Achtung: Wer eine Karte\n"
            "  ziehen muss, weil er keine legen kann/will, der muss für diese Runde aus-\n"
            "  setzen.\n"
            "SONDERREGELN:\n"
            "  Ein Bube darf auf jede andere Karte gelegt werden (auch auf andere Buben).\n"
            "  Der ihn ausspielende Spieler darf nach dem Legen die nächste auszuspielende\n"
            "  Farbe wählen.\n"
            "  Wird eine 7 gelegt, so muss der andere Spieler zwei Karten ziehen, bevor er\n"
            "  seinen Zug ausführt, es sei denn, er kann mit einer 7 oder 10 antworten.\n"
            "  Wird eine 10 gelegt, so muss der andere Spieler eine Karte ziehen, bevor er\n"
            "  seinen Zug ausführt, es sei denn, er kann mit einer 7 oder 10 antworten.\n"
            "  \"Antworten\" heißt, auf eine \"Ziehkarte\" (7 oder 10) sofort eine andere\n"
            "  (beliebige) Ziehkarte zu legen und so die Anzahl der zu ziehenden Karten zu\n"
            "  erhöhen und die Bürde des Ziehens wieder dem anderen Spieler zu übertragen.\n"
            "  Ein Ass lässt den gegnerischen Spieler eine Runde aussetzen.\n"
            "\n"
            "Die genauen Regeln sollten unter /mnt/floppy/home/Mau-Mau-Regeln.txt liegen.\n",
            "Sie",
            "Ihr Gegner",
            "Sie und Ihr Gegner",
            "Aktuelle Farbe",
            "Sie müssen jetzt %i %s ziehen, können dies aber auch abwehren.",
            "Möchten Sie eine 7 oder 10 legen?",
            "Karte",
            "Karten",
            "Welche Karte möchten Sie legen? (\"keine\" für keine)",
            "keine",
            "Diese Karte haben Sie leider nicht.",
            "(nur 7 oder 10).",
            "Herzlichen Glückwunsch! Sie haben das Spiel gewonnen!",
            "Sie müssen %i %s ziehen.",
            "Sie müssen aussetzen. Drücken Sie die Eingabetaste.",
            "Diese Karte können Sie leider nicht ablegen",
            "Da Sie einen Buben gelegt haben, dürfen Sie jetzt eine Farbe wählen.",
            "Möchten Sie Kreuz (K), Pik (P), Herz (H) oder Karo (C)?",
            "Leider haben Sie verloren!"
};

const char english_c[2] = "yn";
const char german_c[2]  = "jn";

#define UNK_PARS 0
#define UNK_PAR 1
#define HELP 2
#define YOU 3
#define OPPONENT 4
#define YOU_OPPONENT 5
#define CUR_COL 6
#define YOU_DRAW_OR_NOT 7
#define DRAWING_CARD 8
#define CARD 9
#define CARDS 10
#define WHICH_CARD 11
#define NONE 12
#define YOU_DONT_HAVE 13
#define JUST_7_10 14
#define YOU_WON 15
#define MUST_DRAW 16
#define MUST_PAUSE 17
#define YOU_CANNOT 18
#define PUT_JACK 19
#define WHICH_COLOUR 20
#define YOU_LOST 21
#define Y 0
#define N 1

int main(int argc, char *argv[])
{
    maumau_t *game;
    FILE *graphic = NULL;
    int i, _card = 0, playerMust[2] = {0, 0}, curcol, colcount[4], greatest, greatest_i, maybe, mau = 0, _take = 0, found, ignorePlayer1 = 0, c;
    char inp[32], pafterclear[128];
    char *lang, *readln;
    const char **language, *chars;

    lang = getenv("LANG");
    language = english;
    chars = english_c;
    if ((lang != NULL) && !strncmp(lang, "de", 2))
    {
        language = german;
        chars = german_c;
    }

    if (argc > 2)
    {
        fprintf(stderr, "%s\n", language[UNK_PARS]);
        return EXIT_FAILURE;
    }
    if (argc == 2)
    {
        if (!strcmp(argv[1], "-h") || !strcmp(argv[1], "-?") || !strcmp(argv[1], "--help"))
        {
            printf(language[HELP]);
            return EXIT_SUCCESS;
        }
        else if (!strcmp(argv[1], "-v") || !strcmp(argv[1], "--version"))
        {
            printf("MyxMauMau (MyX games) 0.5\nWritten by Max Reitz\n\n");
            printf("Using libmaumau 0.3\nWritten by Max Reitz with support from irc.euirc.net#lost\n");
            return EXIT_SUCCESS;
        }
        else
        {
            fprintf(stderr, "%s\n", language[UNK_PAR]);
            return EXIT_FAILURE;
        }
    }

    game = newGame(with 2 players);
    startGame(game);
    shuffle(game->_stack);
    action(game, player 1 takes 6 cards);
    action(game, player 2 takes 6 cards);
    game->_currentCard._value = game->_stack[--game->_stackSize]._value;
    curcol = game->_currentCard._single._colour;

    pafterclear[0] = 0;

    for (;;)
    {
        printf("\33[2J");

        if (mau)
        {
            if (mau == 0x01)
                printf("%s: \"", language[YOU]);
            else if (mau == 0x02)
                printf("%s: \"", language[OPPONENT]);
            else
                printf("%s: \"", language[YOU_OPPONENT]);

            printf("Mau!\"\n\n");
            mau = 0;
        }

        printf("%s: ", language[CUR_COL]);
        switch (curcol)
        {
            case (MAUMAU_COLOUR_HEARTS):
                printf("\33[31m");
                if (graphic)
                    fputc(SYMBOL_HEARTS, graphic);
                else
#ifndef FULL_UNICODE
                    putchar('H');
#else
                    printf("♥");
#endif
                break;
            case (MAUMAU_COLOUR_DIAMONDS):
                printf("\33[31m");
                if (graphic)
                    fputc(SYMBOL_DIAMONDS, graphic);
                else
#ifndef FULL_UNICODE
                    putchar('C');
#else
                    printf("♦");
#endif
                break;
            case (MAUMAU_COLOUR_CLUBS):
                printf("\33[30;1m");
                if (graphic)
                    fputc(SYMBOL_CLUBS, graphic);
                else
#ifndef FULL_UNICODE
                    putchar('K');
#else
                    printf("♣");
#endif
                break;
            case (MAUMAU_COLOUR_SPADES):
                printf("\33[30;1m");
                if (graphic)
                    fputc(SYMBOL_SPADES, graphic);
                else
#ifndef FULL_UNICODE
                    putchar('P');
#else
                    printf("♠");
#endif
                break;
        }
        printf("\33[0m\n\n");

        //BEGINN "KARTEN DES GEGNERS"
        for (i = 0; i < game->_player[1]._cards; i++)
        {
            if (graphic)
            {
                if (!i)
                    fprintf(graphic, "\xDA\xC4\xC4\xC4");
                else
                    fprintf(graphic, "\xC2\xC4\xC4\xC4");
            }
            else
#ifndef FULL_UNICODE
                printf("+---");
#else
            {
                if (!i)
                    printf("┌───");
                else
                    printf("┬───");
            }
#endif
        }
        if (graphic)
            fprintf(graphic, "\xBF\n");
        else
#ifndef FULL_UNICODE
            printf("+\n");
#else
            printf("┐\n");
#endif

        for (i = 0; i < game->_player[1]._cards; i++)
        {
            if (graphic)
                fprintf(graphic, "\xB3\33[34m\xB0\xB0\xB0\33[0m");
            else
#ifndef FULL_UNICODE
                printf("|\33[34m###\33[0m");
#else
                printf("│\33[34m\u2591\u2591\u2591\33[0m");
#endif
        }
        if (graphic)
            fputc('\xB3', graphic);
        else
#ifndef FULL_UNICODE
            putchar('|');
#else
        printf("│");
#endif
        putchar('\n');
        for (i = 0; i < game->_player[1]._cards; i++)
        {
            if (graphic)
                fprintf(graphic, "\xB3\33[34m\xB0\xB0\xB0\33[0m");
            else
#ifndef FULL_UNICODE
                printf("|\33[34m###\33[0m");
#else
                printf("│\33[34m\u2591\u2591\u2591\33[0m");
#endif
        }
        if (graphic)
            fprintf(graphic, "\xB3\n");
        else
#ifndef FULL_UNICODE
            printf("|\n");
#else
            printf("│\n");
#endif

        for (i = 0; i < game->_player[1]._cards; i++)
        {
            if (graphic)
            {
                if (!i)
                    fprintf(graphic, "\xC0\xC4\xC4\xC4");
                else
                    fprintf(graphic, "\xC1\xC4\xC4\xC4");
            }
            else
#ifndef FULL_UNICODE
                printf("+---");
#else
            {
                if (!i)
                    printf("└───");
                else
                    printf("┴───");
            }
#endif
        }
        if (graphic)
            fprintf(graphic, "\xD9\n");
        else
#ifndef FULL_UNICODE
            printf("+\n");
#else
            printf("┘\n");
#endif
        //ENDE "KARTEN DES GEGNERS"

        //BEGINN "STAPEL"
        if (graphic)
            fprintf(graphic, "\xC9\xCD\xCD\xCD\xBB \xC9\xCD\xCD\xCD\xBB\n\xBA ");
        else
#ifndef FULL_UNICODE
            printf("+===+ +===+\n| ");
#else
            printf("╔═══╗ ╔═══╗\n║ ");
#endif
        switch (game->_currentCard._single._colour)
        {
            case (MAUMAU_COLOUR_HEARTS):
                printf("\33[31m");
                if (graphic)
                    fputc(SYMBOL_HEARTS, graphic);
                else
#ifndef FULL_UNICODE
                    putchar('H');
#else
                    printf("♥");
#endif
                break;
            case (MAUMAU_COLOUR_DIAMONDS):
                printf("\33[31m");
                if (graphic)
                    fputc(SYMBOL_DIAMONDS, graphic);
                else
#ifndef FULL_UNICODE
                    putchar('C');
#else
                    printf("♦");
#endif
                break;
            case (MAUMAU_COLOUR_CLUBS):
                printf("\33[30;1m");
                if (graphic)
                    fputc(SYMBOL_CLUBS, graphic);
                else
#ifndef FULL_UNICODE
                    putchar('K');
#else
                    printf("♣");
#endif
                break;
            case (MAUMAU_COLOUR_SPADES):
                printf("\33[30;1m");
                if (graphic)
                    fputc(SYMBOL_SPADES, graphic);
                else
#ifndef FULL_UNICODE
                    putchar('P');
#else
                    printf("♠");
#endif
                break;
        }
        printf("\33[0m ");
        if (graphic)
            fprintf(graphic, "\xBA \xBA\33[34m\xB0\xB0\xB0\33[0m\xBA\n\xBA");
        else
#ifndef FULL_UNICODE
            printf("| |\33[34m###\33[0m|\n|");
#else
            printf("║ ║\33[34m\u2591\u2591\u2591\33[0m║\n║");
#endif
        printf(" %c ", value_char[(int)game->_currentCard._single._value]);
        if (graphic)
        {
            fprintf(graphic, "\xBA \xBA\33[34m\xB0\xB0\xB0\33[0m\xBA\n");
            fprintf(graphic, "\xC8\xCD\xCD\xCD\xBC \xC8\xCD\xCD\xCD\xBC\n");
        }
        else
        {
#ifndef FULL_UNICODE
            printf("| |\33[34m###\33[0m|\n");
            printf("+===+ +===+\n");
#else
            printf("║ ║\33[34m\u2591\u2591\u2591\33[0m║\n");
            printf("╚═══╝ ╚═══╝\n");
#endif
        }
        //ENDE "STAPEL"

        //BEGINN "EIGENE KARTEN"
        for (i = 0; i < game->_player[0]._cards; i++)
        {
            if (graphic)
            {
                if (!i)
                    fprintf(graphic, "\xDA\xC4\xC4\xC4");
                else
                    fprintf(graphic, "\xC2\xC4\xC4\xC4");
            }
            else
#ifndef FULL_UNICODE
                printf("+---");
#else
            {
                if (!i)
                    printf("┌───");
                else
                    printf("┬───");
            }
#endif
        }
        if (graphic)
            fprintf(graphic, "\xBF\n");
        else
#ifndef FULL_UNICODE
            printf("+\n");
#else
            printf("┐\n");
#endif

        for (i = 0; i < game->_player[0]._cards; i++)
        {
            if (graphic)
                fprintf(graphic, "\xB3 ");
            else
#ifndef FULL_UNICODE
                printf("| ");
#else
                printf("│ ");
#endif
            switch (game->_player[0]._hand[i]._single._colour)
            {
                case (MAUMAU_COLOUR_HEARTS):
                    printf("\33[31m");
                    if (graphic)
                        fputc(SYMBOL_HEARTS, graphic);
                    else
#ifndef FULL_UNICODE
                        putchar('H');
#else
                        printf("♥");
#endif
                    break;
                case (MAUMAU_COLOUR_DIAMONDS):
                    printf("\33[31m");
                    if (graphic)
                        fputc(SYMBOL_DIAMONDS, graphic);
                    else
#ifndef FULL_UNICODE
                        putchar('C');
#else
                        printf("♦");
#endif
                    break;
                case (MAUMAU_COLOUR_CLUBS):
                    printf("\33[30;1m");
                    if (graphic)
                        fputc(SYMBOL_CLUBS, graphic);
                    else
#ifndef FULL_UNICODE
                        putchar('K');
#else
                        printf("♣");
#endif
                    break;
                case (MAUMAU_COLOUR_SPADES):
                    printf("\33[30;1m");
                    if (graphic)
                        fputc(SYMBOL_SPADES, graphic);
                    else
#ifndef FULL_UNICODE
                        putchar('P');
#else
                        printf("♠");
#endif
                    break;
            }
            printf("\33[0m ");
        }
        if (graphic)
            fputc('\xB3', graphic);
        else
#ifndef FULL_UNICODE
            putchar('|');
#else
            printf("│");
#endif
        putchar('\n');
        for (i = 0; i < game->_player[0]._cards; i++)
        {
            if (graphic)
                fprintf(graphic, "\xB3 ");
            else
#ifndef FULL_UNICODE
                printf("| ");
#else
                printf("│ ");
#endif
            printf("%c ", value_char[(int)game->_player[0]._hand[i]._single._value]);
        }
        if (graphic)
            fprintf(graphic, "\xB3\n");
        else
#ifndef FULL_UNICODE
            printf("|\n");
#else
            printf("│\n");
#endif

        for (i = 0; i < game->_player[0]._cards; i++)
        {
            if (graphic)
            {
                if (!i)
                    fprintf(graphic, "\xC0\xC4\xC4\xC4");
                else
                    fprintf(graphic, "\xC1\xC4\xC4\xC4");
            }
            else
#ifndef FULL_UNICODE
                printf("+---");
#else
            {
                if (!i)
                    printf("└───");
                else
                    printf("┴───");
            }
#endif
        }
        if (graphic)
            fprintf(graphic, "\xD9\n");
        else
#ifndef FULL_UNICODE
            printf("+\n");
#else
            printf("┘\n");
#endif
        //ENDE "EIGENE KARTEN"

        //BEGINN "EIGENE KARTENNUMMERN"
        i = 0;
        while (i < game->_player[0]._cards)
            printf("%3i ", ++i);
        putchar('\n');
        //ENDE "EIGENE KARTENNUMMERN"

        //BEGINN "SPIELER LEGT"
        if (ignorePlayer1)
        {
            ignorePlayer1 = 0;
            goto Player2sTurn;
        }
        if (playerMust[0] & MUST_TAKE)
        {
            playerMust[0] &= ~MUST_TAKE;
            for (i = 0, found = 0; i < game->_player[0]._cards; i++)
            {
                if ((game->_player[0]._hand[i]._single._value == MAUMAU_VALUE_7) || (game->_player[0]._hand[i]._single._value == MAUMAU_VALUE_10))
                {
                    found = 1;
                    break;
                }
            }
            if (found)
            {
                putchar('\n');
                printf(language[YOU_DRAW_OR_NOT], _take, (_take == 1) ? language[CARD] : language[CARDS]);
                putchar('\n');
                printf("%s ", language[DRAWING_CARD]);
#ifdef MYXOMYCOTA
                printf("[%c/%c] ", chars[Y], chars[N]);
                fflush(stdout);
                c = 0;
                while ((c != chars[Y]) && (c != chars[N]))
                    c = tolower(getchar());
                printf("\n");
#else
                do
                {
                    printf("[%c/%c] ", chars[Y], chars[N]);
                    fflush(stdout);
                    clearerr(stdin);
                    readln = readline(NULL);
                    memset(inp, 0, 32);
                    strncpy(inp, readln, 31);
                    if (!*inp)
                        continue;
                } while ((strlen(inp) != 1) || ((tolower(*inp) != chars[Y]) && (tolower(*inp) != chars[N])));
                c = tolower(*inp);
#endif
                if (c == chars[N])
                    found = 0;
                else
                {
                    printf("\n%s\n", language[WHICH_CARD]);
                    for (;;)
                    {
                        readln = readline("> ");
                        memset(inp, 0, 32);
                        strncpy(inp, readln, 31);
                        if (!*inp)
                            continue;
                        for (i = 0; i < strlen(inp); i++)
                            inp[i] = tolower(inp[i]);
                        if (!strcmp(inp, language[NONE]))
                        {
                            _card = 0;
                            break;
                        }
                        _card = atoi(inp);
                        if ((_card < 1) || (_card > game->_player[0]._cards))
                        {
                            printf("%s\n", language[YOU_DONT_HAVE]);
                            continue;
                        }
                        else if ((game->_player[0]._hand[_card-1]._single._value != MAUMAU_VALUE_7 ) &&
                                  (game->_player[0]._hand[_card-1]._single._value != MAUMAU_VALUE_10))
                        {
                            printf("%s %s\n", language[YOU_CANNOT], language[JUST_7_10]);
                            continue;
                        }
                        break;
                    }
                    if (!_card)
                        found = 0;
                    else
                    {
                        putCurrentCardUnderStack(game);
                        game->_currentCard._value = game->_player[0]._hand[_card-1]._value;
                        if (_card < game->_player[0]._cards)
                            memmove(&game->_player[0]._hand[_card-1], &game->_player[0]._hand[_card], sizeof(card_t)*(game->_player[0]._cards-_card));
                        game->_player[0]._cards--;

                        curcol = game->_currentCard._single._colour;
                        switch (game->_currentCard._single._value)
                        {
                            case (MAUMAU_VALUE_7):
                                playerMust[1] |= MUST_TAKE;
                                _take += 2;
                                break;
                            case (MAUMAU_VALUE_10):
                                playerMust[1] |= MUST_TAKE;
                                _take++;
                                break;
                        }
                        if (game->_player[0]._cards == 1)
                            mau |= 0x01;
                        else if (!game->_player[0]._cards)
                        {
                            printf("\33[32;1mMAU MAU!\33[0m\n\n%s\n", language[YOU_WON]);
                            break;
                        }
                    }
                }
                ignorePlayer1 = 1;
            }
            if (!found)
            {
                putchar('\n');
                sprintf(pafterclear, language[MUST_DRAW], _take, (_take == 1) ? language[CARD] : language[CARDS]);
                putchar('\n');
                action(game, player 1 takes _take cards);
                _take = 0;
                ignorePlayer1 = 0;
            }
            continue; //Alles neu zeichnen
        }
        if (*pafterclear)
        {
            printf(pafterclear);
            *pafterclear = 0;
        }
        if (playerMust[0] & MUST_WAIT)
        {
            playerMust[0] &= ~MUST_WAIT;
            printf("\n%s\n", language[MUST_PAUSE]);
            while (getchar() != '\n');
        }
        else
        {
            printf("\n%s\n", language[WHICH_CARD]);
            for (;;)
            {
                readln = readline("> ");
                memset(inp, 0, 32);
                strncpy(inp, readln, 31);
                if (!*inp)
                    continue;
                for (i = 0; i < strlen(inp); i++)
                    inp[i] = tolower(inp[i]);
                if (!strcmp(inp, language[NONE]))
                {
                    _card = 0;
                    break;
                }
                else if (!strcmp(inp, "quit"))
                {
                    _card = -1;
                    break;
                }
                _card = atoi(inp);
                if ((_card < 1) || (_card > game->_player[0]._cards))
                {
                    printf("%s\n", language[YOU_DONT_HAVE]);
                    continue;
                }
                else if (game->_player[0]._hand[_card-1]._single._value == MAUMAU_VALUE_JACK)
                    break;
                else if ((game->_player[0]._hand[_card-1]._single._value  != game->_currentCard._single._value) &&
                          (game->_player[0]._hand[_card-1]._single._colour != curcol                           ))
                {
                    printf("%s\n", language[YOU_CANNOT]);
                    continue;
                }
                break;
            }

            if (_card == -1)
                break;

            if (!_card)
                action(game, player 1 takes 1 card);
            else
            {
                putCurrentCardUnderStack(game);
                game->_currentCard._value = game->_player[0]._hand[_card-1]._value;
                if (_card < game->_player[0]._cards)
                    memmove(&game->_player[0]._hand[_card-1], &game->_player[0]._hand[_card], sizeof(card_t)*(game->_player[0]._cards-_card));
                game->_player[0]._cards--;

                if (game->_currentCard._single._value != MAUMAU_VALUE_JACK)
                {
                    curcol = game->_currentCard._single._colour;
                    switch (game->_currentCard._single._value)
                    {
                        case (MAUMAU_VALUE_ACE):
                            playerMust[1] |= MUST_WAIT;
                            break;
                        case (MAUMAU_VALUE_7):
                            playerMust[1] |= MUST_TAKE;
                            _take += 2;
                            break;
                        case (MAUMAU_VALUE_10):
                            playerMust[1] |= MUST_TAKE;
                            _take++;
                            break;
                    }
                }
                else if (game->_player[0]._cards)
                {
                    printf("%s\n", language[PUT_JACK]);
                    for (;;)
                    {
                        printf("%s ", language[WHICH_COLOUR]);
                        fflush(stdout);
                        clearerr(stdin);
                        readln = readline(NULL);
                        memset(inp, 0, 32);
                        strncpy(inp, readln, 31);
                        if (!*inp)
                            continue;
                        *inp = toupper(*inp);
                        if ((*inp == 'K') || (*inp == 'P') || (*inp == 'H') || (*inp == 'C'))
                            break;
                    }
                    switch (*inp)
                    {
                        case ('K'):
                            curcol = MAUMAU_COLOUR_CLUBS;
                            break;
                        case ('P'):
                            curcol = MAUMAU_COLOUR_SPADES;
                            break;
                        case ('H'):
                            curcol = MAUMAU_COLOUR_HEARTS;
                            break;
                        case ('C'):
                            curcol = MAUMAU_COLOUR_DIAMONDS;
                            break;
                    }
                }
            }

            if (game->_player[0]._cards == 1)
                mau |= 0x01;
            else if (!game->_player[0]._cards)
            {
                printf("\33[32;1mMAU MAU!\33[0m\n\n%s\n", language[YOU_WON]);
                break;
            }
        }
        //ENDE "SPIELER LEGT"

        Player2sTurn:

        //BEGINN "GEGNER LEGT"
        if (playerMust[1] & MUST_TAKE)
        {
            playerMust[1] &= ~MUST_TAKE;
            for (i = 0, found = 0; i < game->_player[0]._cards; i++)
            {
                if ((game->_player[1]._hand[i]._single._value == MAUMAU_VALUE_7) || (game->_player[1]._hand[i]._single._value == MAUMAU_VALUE_10))
                {
                    found = i+1;
                    break;
                }
            }
            if (found)
            {
                putCurrentCardUnderStack(game);
                game->_currentCard._value = game->_player[1]._hand[found-1]._value;
                if (_card < game->_player[1]._cards)
                    memmove(&game->_player[1]._hand[found-1], &game->_player[1]._hand[found], sizeof(card_t)*(game->_player[1]._cards-found));
                game->_player[1]._cards--;

                curcol = game->_currentCard._single._colour;
                switch (game->_currentCard._single._value)
                {
                    case (MAUMAU_VALUE_7):
                        playerMust[0] |= MUST_TAKE;
                        _take += 2;
                        break;
                    case (MAUMAU_VALUE_10):
                        playerMust[0] |= MUST_TAKE;
                        _take++;
                        break;
                }
                if (game->_player[1]._cards == 1)
                    mau |= 0x02;
                else if (!game->_player[1]._cards)
                {
                    printf("\33[31;1mMAU MAU!\33[0m\n\n%s\n", language[YOU_LOST]);
                    break;
                }
                continue;
            }
            else
            {
                action(game, player 2 takes _take cards);
                _take = 0;
                ignorePlayer1 = 1;
                continue;
            }
        }
        if (playerMust[1] & MUST_WAIT)
            playerMust[1] &= ~MUST_WAIT;
        else
        {
            for (i = 0, _card = 0, maybe = 0; i < game->_player[1]._cards; i++)
            {
                if (game->_player[1]._hand[i]._single._value == MAUMAU_VALUE_JACK)
                    maybe = i+1;
                else if ((game->_player[1]._hand[i]._single._value  == game->_currentCard._single._value) ||
                          (game->_player[1]._hand[i]._single._colour == curcol                           ))
                {
                    _card = i+1;
                    break;
                }
            }

            if (!_card && maybe)
                _card = maybe;

            if (!_card)
                action(game, player 2 takes 1 card);
            else
            {
                putCurrentCardUnderStack(game);
                game->_currentCard._value = game->_player[1]._hand[_card-1]._value;
                if (_card < game->_player[1]._cards)
                    memmove(&game->_player[1]._hand[_card-1], &game->_player[1]._hand[_card], sizeof(card_t)*(game->_player[1]._cards-_card));
                game->_player[1]._cards--;

                if (game->_currentCard._single._value != MAUMAU_VALUE_JACK)
                {
                    curcol = game->_currentCard._single._colour;
                    switch (game->_currentCard._single._value)
                    {
                        case (MAUMAU_VALUE_ACE):
                            playerMust[0] |= MUST_WAIT;
                            break;
                        case (MAUMAU_VALUE_7):
                            playerMust[0] |= MUST_TAKE;
                            _take += 2;
                            break;
                        case (MAUMAU_VALUE_10):
                            playerMust[0] |= MUST_TAKE;
                            _take++;
                            break;
                    }
                }
                else if (game->_player[1]._cards)
                {
                    memset(colcount, 0, 4*sizeof(int));
                    for (i = 0; i < game->_player[1]._cards; i++)
                        colcount[(int)game->_player[1]._hand[i]._single._colour]++;
                    greatest = 0;
                    for (i = 0, greatest_i = 0; i < 4; i++)
                    {
                        if (colcount[i] > greatest)
                        {
                            greatest = colcount[i];
                            greatest_i = i;
                        }
                    }
                    curcol = greatest_i;
                }
            }

            if (game->_player[1]._cards == 1)
                mau |= 0x02;
            else if (!game->_player[1]._cards)
            {
                printf("\33[31;1mMAU MAU!\33[0m\n\n%s\n", language[YOU_LOST]);
                break;
            }
        }
        //ENDE "GEGNER LEGT"
    }

    free(game);
    return EXIT_SUCCESS;
}
